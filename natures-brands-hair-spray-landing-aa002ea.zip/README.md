# Nature's Brands Organic Hair Spray Landing Page

Conversion-focused static landing page for the Nature's Brands 8 oz Organic Hair Spray. The page sends quantity selections into the existing Nature's Brands Shopify cart and checkout.

## Deploy

This is a portable static site with no build step.

- Publish directory: `dist`
- Entry file: `dist/index.html`
- Local preview: serve the `dist` directory with any static web server

For Netlify, Cloudflare Pages, Vercel, GitHub Pages, or another static host, select `dist` as the output/publish directory. Do not deploy the repository root as the website root unless the platform lets you map requests into `dist`.

## Main files

- `dist/index.html` — storefront structure and initial product/offer block
- `dist/styles.css` — original landing-page styles
- `dist/full-story.js` / `dist/full-story.css` — long-form educational story
- `dist/conversion-upgrade.js` / `dist/conversion-upgrade.css` — 8 oz offer, conversion sections, responsive refinements, and Shopify cart synchronization
- `dist/listing-images.js` — optimized listing-image manifest
- `dist/creator-videos.js` — creator-video manifest

## Connect approved creator videos

1. Add browser-ready MP4 or WebM files under `dist/assets/creator/`.
2. Add an authentic poster frame for each video when available.
3. Update the matching `src`, `poster`, title, and summary fields in `dist/creator-videos.js`.

Until a real source is added, the creator section intentionally displays an editing preview and does not fabricate footage, quotes, or results.

## Shopify checkout

The current 8 oz Shopify variant is configured in `dist/conversion-upgrade.js`. Quantity buttons generate Shopify cart permalinks and keep the hero, sticky purchase bar, offer recap, and closing CTA synchronized.

Before publishing a campaign, re-verify the variant ID, price, availability, shipping offer, guarantee terms, creator permissions, and all product claims against the live store.
